import { Settings } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '../../../components/ui/card'
import { Breadcrumb } from '../../../components/ui/breadcrumb'
import { Badge } from '../../../components/ui/badge'

export default function SettingsPage() {
  return (
    <div className="space-y-10 pb-16 select-none">
      <div className="space-y-3">
        <Breadcrumb items={[{ label: 'Dashboard', href: '/' }, { label: 'Settings' }]} />
        <h1 className="text-dashboard-title font-extrabold text-slate-900 tracking-tight">
          Settings
        </h1>
        <p className="text-[22px] font-medium text-slate-500">
          Application preferences and configuration
        </p>
      </div>

      <Card className="border border-slate-200/90 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-6">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-600">
              <Settings className="h-9 w-9 icon-36" strokeWidth={1.75} />
            </div>
            <div>
              <CardTitle className="text-card-title font-extrabold text-slate-900">System Preferences</CardTitle>
              <Badge variant="secondary" className="mt-2 text-[16px] font-bold px-3 py-1 bg-slate-100 text-slate-700">
                Coming soon
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-[22px] font-medium text-slate-500 leading-relaxed">
            Settings for currency, notifications, and account preferences will be available in a future update.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
